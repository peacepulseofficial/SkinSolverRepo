import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import 'no_type_selected_sheet_widget.dart' show NoTypeSelectedSheetWidget;
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class NoTypeSelectedSheetModel
    extends FlutterFlowModel<NoTypeSelectedSheetWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
