import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import 'no_previous_scans_widget.dart' show NoPreviousScansWidget;
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class NoPreviousScansModel extends FlutterFlowModel<NoPreviousScansWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
