import '/components/rating_header_widget.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import '/flutter_flow/custom_functions.dart' as functions;
import 'results_page_skin_ratings_copy_widget.dart'
    show ResultsPageSkinRatingsCopyWidget;
import 'package:flutter/material.dart';
import 'package:flutter/scheduler.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:percent_indicator/percent_indicator.dart';
import 'package:provider/provider.dart';

class ResultsPageSkinRatingsCopyModel
    extends FlutterFlowModel<ResultsPageSkinRatingsCopyWidget> {
  ///  State fields for stateful widgets in this page.

  // Model for ratingHeader component.
  late RatingHeaderModel ratingHeaderModel;

  @override
  void initState(BuildContext context) {
    ratingHeaderModel = createModel(context, () => RatingHeaderModel());
  }

  @override
  void dispose() {
    ratingHeaderModel.dispose();
  }
}
