import '/components/empty_chat_widget.dart';
import '/flutter_flow/flutter_flow_animations.dart';
import '/flutter_flow/flutter_flow_icon_button.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import 'dart:math';
import '/custom_code/actions/index.dart' as actions;
import '/flutter_flow/custom_functions.dart' as functions;
import 'dermatologist_widget.dart' show DermatologistWidget;
import 'package:flutter/material.dart';
import 'package:flutter/scheduler.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class DermatologistModel extends FlutterFlowModel<DermatologistWidget> {
  ///  State fields for stateful widgets in this page.

  // State field(s) for ListViewCurrent widget.
  ScrollController? listViewCurrent;
  // State field(s) for textPrompt widget.
  FocusNode? textPromptFocusNode;
  TextEditingController? textPromptTextController;
  String? Function(BuildContext, String?)? textPromptTextControllerValidator;
  // Stores action output result for [Custom Action - invokeChatGPTDermatologist] action in IconButton widget.
  dynamic? chatResult;

  @override
  void initState(BuildContext context) {
    listViewCurrent = ScrollController();
  }

  @override
  void dispose() {
    listViewCurrent?.dispose();
    textPromptFocusNode?.dispose();
    textPromptTextController?.dispose();
  }
}
