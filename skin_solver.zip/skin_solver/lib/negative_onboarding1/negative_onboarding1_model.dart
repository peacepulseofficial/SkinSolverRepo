import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import 'negative_onboarding1_widget.dart' show NegativeOnboarding1Widget;
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class NegativeOnboarding1Model
    extends FlutterFlowModel<NegativeOnboarding1Widget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
