import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import 'onboarding10_widget.dart' show Onboarding10Widget;
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:percent_indicator/percent_indicator.dart';
import 'package:provider/provider.dart';

class Onboarding10Model extends FlutterFlowModel<Onboarding10Widget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
