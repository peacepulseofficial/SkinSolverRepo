import '/components/no_type_selected_sheet_widget.dart';
import '/flutter_flow/flutter_flow_drop_down.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import '/flutter_flow/form_field_controller.dart';
import '/custom_code/actions/index.dart' as actions;
import 'new_plan_page_widget.dart' show NewPlanPageWidget;
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class NewPlanPageModel extends FlutterFlowModel<NewPlanPageWidget> {
  ///  State fields for stateful widgets in this page.

  // State field(s) for DropDownSkinType widget.
  String? dropDownSkinTypeValue;
  FormFieldController<String>? dropDownSkinTypeValueController;
  // State field(s) for DropDownAcneType widget.
  String? dropDownAcneTypeValue;
  FormFieldController<String>? dropDownAcneTypeValueController;
  // State field(s) for TextField widget.
  FocusNode? textFieldFocusNode;
  TextEditingController? textController;
  String? Function(BuildContext, String?)? textControllerValidator;
  // Stores action output result for [Custom Action - invokeChatGPTRoutineSelection] action in Button widget.
  String? routineNumber;

  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {
    textFieldFocusNode?.dispose();
    textController?.dispose();
  }
}
