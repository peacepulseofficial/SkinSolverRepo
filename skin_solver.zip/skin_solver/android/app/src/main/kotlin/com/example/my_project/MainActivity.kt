package com.mycompany.acnesolver

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
